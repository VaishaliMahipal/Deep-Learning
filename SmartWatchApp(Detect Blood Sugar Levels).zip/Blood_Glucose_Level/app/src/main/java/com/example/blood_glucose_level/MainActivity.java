package com.example.blood_glucose_level;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.wearable.activity.WearableActivity;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.RandomForest;
import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.SerializationHelper;
import weka.core.SparseInstance;
import weka.core.converters.CSVLoader;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.NumericToNominal;

import static weka.core.SerializationHelper.read;
public class MainActivity extends WearableActivity implements SensorEventListener {
    private SensorManager sensorManager;
    Sensor accelerometer;
    Sensor gyroscope;
    Sensor heartRate;
    long startTime = 0;
    double[] accMag = new double[50];
    double[] gyrosMag = new double[50];
    double[] heartMag = new double[50];
    int acc=0;
    int gyros=0;
    int heart=0;
    double minAcc=0;
    double maxAcc=0;
    double varAcc=0;
    double stdAcc=0;
    double zeroAcc=0;
    double meanAcc=0;
    double enerAcc =0 ;
    double minGyros=0;
    double maxGyros=0;
    double varGyros=0;
    double stdGyros=0;
    double zeroGyros=0;
    double meanGyros=0;
    double enerGyros =0 ;
    double minHeart=0;
    double maxHeart=0;
    double varHeart=0;
    double stdHeart=0;
    double zeroHeart=0;
    double meanHeart=0;
    double enerHeart =0 ;
    int interval=2;
    TextView glucoseValue,glucoseLevel;



    RandomForest tree;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        glucoseValue= (TextView)findViewById(R.id.textView2);
        glucoseLevel=(TextView)findViewById(R.id.textView4);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.BODY_SENSORS) != PackageManager.PERMISSION_GRANTED)
        {requestPermissions(new String[]{Manifest.permission.BODY_SENSORS},1000);}


        sensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroscope=sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        heartRate=sensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE);
        sensorManager.registerListener(MainActivity.this,accelerometer,sensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(MainActivity.this,gyroscope,sensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(MainActivity.this,heartRate,sensorManager.SENSOR_DELAY_NORMAL);
        // Enables Always-on
        setAmbientEnabled();
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor = sensorEvent.sensor;
        if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {

            double magnitude = Math.sqrt(sensorEvent.values[0]*sensorEvent.values[0]+sensorEvent.values[1]*sensorEvent.values[1]+sensorEvent.values[2]*sensorEvent.values[2]);
            long millis = System.currentTimeMillis() - startTime;
            int seconds = (int) (millis / 1000);
            int minutes = seconds / 60;
            seconds     = seconds % 60;

            if (seconds % interval ==0 || acc==50){
                minAcc=minimum(accMag);
                maxAcc=maximum(accMag);
                varAcc=variance(accMag);
                stdAcc=standardDeviation(accMag);
                meanAcc = Mean(accMag);
                zeroAcc = zeroCrossingRate(accMag);
                enerAcc = energy(accMag);

            }
            else{
                accMag[acc]=magnitude;
                acc++;
            }


        }
        else if (sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            double magnitude = Math.sqrt(sensorEvent.values[0]*sensorEvent.values[0]+sensorEvent.values[1]*sensorEvent.values[1]+sensorEvent.values[2]*sensorEvent.values[2]);
            long millis = System.currentTimeMillis() - startTime;
            int seconds = (int) (millis / 1000);
            int minutes = seconds / 60;
            seconds     = seconds % 60;

            if (seconds % interval ==0 || gyros==50){
                minGyros=minimum(gyrosMag);
                maxGyros=maximum(gyrosMag);
                varGyros=variance(gyrosMag);
                stdGyros=standardDeviation(gyrosMag);
                meanGyros = Mean(gyrosMag);
                zeroGyros = zeroCrossingRate(gyrosMag);
                enerGyros = energy(gyrosMag);

            }
            else{
                gyrosMag[gyros]=magnitude;
                gyros++;
            }

        }
      else if (sensor.getType() == Sensor.TYPE_HEART_RATE) {
            long millis = System.currentTimeMillis() - startTime;
            int seconds = (int) (millis / 1000);
            int minutes = seconds / 60;
            seconds     = seconds % 60;

            if (seconds % interval ==0 || gyros==50){
                minHeart=minimum(heartMag);
                maxHeart=maximum(heartMag);
                varHeart=variance(heartMag);
                stdHeart=standardDeviation(heartMag);
                meanHeart = Mean(heartMag);
                zeroHeart = zeroCrossingRate(heartMag);
                enerHeart = energy(heartMag);

            }
            else{
                heartMag[heart]=sensorEvent.values[0];
                heart++;
            }

        }


        try {
            training();
            deployingClassification(minAcc,maxAcc,varAcc,stdAcc,zeroAcc,meanAcc,enerAcc,minGyros,maxGyros,varGyros,stdGyros,zeroGyros,meanGyros,enerGyros,minHeart,maxHeart,varHeart,stdHeart,zeroHeart,meanHeart,enerHeart);
        } catch (Exception e) {
            e.printStackTrace();
        }


       /* try {
            deployingRegression(minAcc,maxAcc,varAcc,stdAcc,zeroAcc,meanAcc,enerAcc,minGyros,maxGyros,varGyros,stdGyros,zeroGyros,meanGyros,enerGyros,minHeart,maxHeart,varHeart,stdHeart,zeroHeart,meanHeart,enerHeart);
        } catch (Exception e) {
            e.printStackTrace();
        }*/


    }

   /* public void deployingRegression(double minAcc, double maxAcc, double varAcc, double stdAcc, double zeroAcc, double meanAcc, double enerAcc, double minGyros, double maxGyros, double varGyros, double stdGyros, double zeroGyros, double meanGyros, double enerGyros, double minHeart, double maxHeart, double varHeart, double stdHeart, double zeroHeart, double meanHeart, double enerHeart) throws Exception {

        Classifier rfCLf = null;
        rfCLf = (Classifier) SerializationHelper.read(getAssets().open("Random_Forest_Reg.model"));

        ArrayList<Attribute> attributes = new ArrayList<>();


        attributes.add(new Attribute("hr_data_min\n",0));
        attributes.add(new Attribute("hr_data_max\n",1));
        attributes.add(new Attribute("hr_std_dev\n",2));
        attributes.add(new Attribute("hr_energy\n",3));
        attributes.add(new Attribute("hr_zero_crossing_rate\n",4));
        attributes.add(new Attribute("acc_data_min\n",5));
        attributes.add(new Attribute("acc_data_max\n",6));
        attributes.add(new Attribute("acc_std_dev\n",7));
        attributes.add(new Attribute("acc_energy\n",8));
        attributes.add(new Attribute("acc_zero_crossing_rate\n",9));
        attributes.add(new Attribute("gyro_data_min\n",10));
        attributes.add(new Attribute("gyro_data_max\n",11));
        attributes.add(new Attribute("gyro_std_dev\n",12));
        attributes.add(new Attribute("gyro_energy\n",13));
        attributes.add(new Attribute("gyro_zero_crossing_rate\n",14));

        Instance instance = new SparseInstance(15);


        instance.setValue(attributes.get(0), minHeart);
        instance.setValue(attributes.get(1), maxHeart);
        instance.setValue(attributes.get(2), stdHeart);
        instance.setValue(attributes.get(3), enerHeart);
        instance.setValue(attributes.get(4), zeroHeart);
        instance.setValue(attributes.get(5), minAcc);
        instance.setValue(attributes.get(6), maxAcc);
        instance.setValue(attributes.get(7), stdAcc);
        instance.setValue(attributes.get(8), enerAcc);
        instance.setValue(attributes.get(9), zeroAcc);
        instance.setValue(attributes.get(10), minGyros);
        instance.setValue(attributes.get(11), maxGyros);
        instance.setValue(attributes.get(12), stdGyros);
        instance.setValue(attributes.get(13), enerGyros);
        instance.setValue(attributes.get(14), zeroGyros);



        Instances datasetConfiguration;
        datasetConfiguration = new Instances("Glucose Level", attributes, 0);

        datasetConfiguration.setClassIndex(15);
        instance.setDataset(datasetConfiguration);


        double a4= rfCLf.classifyInstance(instance);
        glucoseValue.setText(""+a4);


    }*/

    public void deployingClassification(double minAcc, double maxAcc, double varAcc, double stdAcc, double zeroAcc, double meanAcc, double enerAcc, double minGyros, double maxGyros, double varGyros, double stdGyros, double zeroGyros, double meanGyros, double enerGyros, double minHeart, double maxHeart, double varHeart, double stdHeart, double zeroHeart, double meanHeart, double enerHeart) throws Exception {

      //  Classifier rfCLf = null;
       // rfCLf = (Classifier) SerializationHelper.read(getAssets().open("Random_Forest.model"));

        ArrayList<Attribute> attributes = new ArrayList<>();


        attributes.add(new Attribute("hr_data_min\n",0));
        attributes.add(new Attribute("hr_data_max\n",1));
        attributes.add(new Attribute("hr_std_dev\n",2));
        attributes.add(new Attribute("hr_energy\n",3));
        attributes.add(new Attribute("hr_zero_crossing_rate\n",4));
        attributes.add(new Attribute("acc_data_min\n",5));
        attributes.add(new Attribute("acc_data_max\n",6));
        attributes.add(new Attribute("acc_std_dev\n",7));
        attributes.add(new Attribute("acc_energy\n",8));
        attributes.add(new Attribute("acc_zero_crossing_rate\n",9));
        attributes.add(new Attribute("gyro_data_min\n",10));
        attributes.add(new Attribute("gyro_data_max\n",11));
        attributes.add(new Attribute("gyro_std_dev\n",12));
        attributes.add(new Attribute("gyro_energy\n",13));
        attributes.add(new Attribute("gyro_zero_crossing_rate\n",14));



        attributes.add(new Attribute("Label", Arrays.asList("1","2"),2));
        Instance instance = new SparseInstance(15);


        instance.setValue(attributes.get(0), minHeart);
        instance.setValue(attributes.get(1), maxHeart);
        instance.setValue(attributes.get(2), stdHeart);
        instance.setValue(attributes.get(3), enerHeart);
        instance.setValue(attributes.get(4), zeroHeart);
        instance.setValue(attributes.get(5), minAcc);
        instance.setValue(attributes.get(6), maxAcc);
        instance.setValue(attributes.get(7), stdAcc);
        instance.setValue(attributes.get(8), enerAcc);
        instance.setValue(attributes.get(9), zeroAcc);
        instance.setValue(attributes.get(10), minGyros);
        instance.setValue(attributes.get(11), maxGyros);
        instance.setValue(attributes.get(12), stdGyros);
        instance.setValue(attributes.get(13), enerGyros);
        instance.setValue(attributes.get(14), zeroGyros);



        Instances datasetConfiguration;
        datasetConfiguration = new Instances("Glucose Level", attributes, 0);

        datasetConfiguration.setClassIndex(15);
        instance.setDataset(datasetConfiguration);
        // Log.d("set:",attributes.get(0)+" "+attributes.get(1)+" "+attributes.get(2)+" "+attributes.get(3)+" "+attributes.get(4)+" "+attributes.get(5)+" "+attributes.get(6));

        // double a1=0;
       // double a1= rfCLf.classifyInstance(instance);
        double a1= tree.classifyInstance(instance);
        if(a1==1)
        {
            glucoseLevel.setText("Decreasing");
        }
        else if(a1==2) {
            glucoseLevel.setText("Increasing");
        }
        else
        {
            glucoseLevel.setText("error");
        }



    }

    private double zeroCrossingRate(double[] data) {

        int length = data.length;
        double num = 0;
        for (int i = 0; i < length - 1; i++)
        {
            if (data[i] * data[i + 1]< 0){
                num++;
            }
        }
        return num / length;
    }

    private double energy(double[] data){
        if(data == null || data.length == 0) return 0.0;
        double sum = 0;
        for(int i=0;i<data.length;i++){
            sum+= Math.pow(data[i],2);
        }
        return sum/data.length;
    }

    private double Mean(double[] data) {
        if(data==null || data.length==0) return 0.0;
        int length= data.length;
        double average=0, sum=0;
        for(int i=0;i<length;i++){
            sum=sum+data[i];
        }
        average=sum/length;
        return average;
    }


    private double standardDeviation(double[] data) {
        if(data==null || data.length==0) return 0.0;
        double s= variance(data);
        s= Math.sqrt(s);
        return s;
    }

    private double variance(double[] data) {
        if(data==null || data.length==0) return 0.0;
        int length= data.length;
        double average=0, s=0, sum=0;
        for(int i=0;i<length;i++){
            sum=sum+data[i];
        }
        average=sum/length;
        for(int i=0;i<length;i++){
            s=s+Math.pow(data[i]-average,2);
        }
        s=s/length;
        return s;
    }

    private double maximum(double[] data) {
        if(data==null || data.length==0) return 0.0;
        int length= data.length;
        double Max = data[0];
        for(int i=0;i<length;i++){
            Max=data[i]<Max?Max:data[i];
        }
        return Max;
    }

    private double minimum(double[] data) {
        if(data==null || data.length==0) return 0.0;
        int length= data.length;
        double Min = data[0];
        for(int i=0;i<length;i++){
            Min=data[i]<Min?data[i]:Min;
        }
        return Min;
    }

    public void training() throws Exception {
        try {
            File file = new File(String.valueOf(getAssets()),"Final_Data_Classification.csv");
            CSVLoader loader = new CSVLoader();
            loader.setSource(file);
            Instances dataC = loader.getDataSet();
            //dataC.setClassIndex(dataC.numAttributes() - 1);
            NumericToNominal convert = new NumericToNominal();
            String[] options = new String[2];
            options[0] = "-R";
            options[1] = "last";  //range of variables to make numeric

            convert.setOptions(options);
            convert.setInputFormat(dataC);

            Instances newData = Filter.useFilter(dataC, convert);
            newData.setClassIndex(newData.numAttributes() - 1);
            Evaluation eval;



            tree = new RandomForest();
            eval = new Evaluation(newData);
            eval.crossValidateModel(tree, newData, 10, new Random(1));

        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
            Toast.makeText(this, "File not found", Toast.LENGTH_SHORT).show();

        }
        catch(IOException e)
        {
            e.printStackTrace();
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}